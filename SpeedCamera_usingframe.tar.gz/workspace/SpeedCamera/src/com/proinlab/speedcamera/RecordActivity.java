package com.proinlab.speedcamera;
import java.util.*;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.media.AudioManager;
import android.media.ToneGenerator;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase.*;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;

public class RecordActivity extends Activity implements CvCameraViewListener2 {

	private Mat mGrayMat0;
	private Mat mHirerchy;

	private Mat mRgba;
	private Mat mGray;

	private List<MatOfPoint> contours;
	MatOfPoint2f approxCurve;
	MatOfPoint2f contour2f;
	
	ToneGenerator toneG_Red = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
	ToneGenerator toneG_Green = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
	
	private int Red_cnt;
	private int Green_cnt;
	double approxDistance;
	
	private String TAG = "OPENCV ERROR";
	private CameraBridgeViewBase mOpenCvCameraView;

	private BaseLoaderCallback mOpenCVCallBack = new BaseLoaderCallback(this) {
		@Override
		public void onManagerConnected(int status) {
			switch (status) {
			case LoaderCallbackInterface.SUCCESS: {
				mOpenCvCameraView.enableView();

			}
				break;
			default: {
				super.onManagerConnected(status);
			}
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_record);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.record_activity_surface_view);
		mOpenCvCameraView.setCvCameraViewListener(this);

	}

	public void onCameraViewStarted(int width, int height) {
		mRgba = new Mat();
		mGray = new Mat();
		mGrayMat0 = new Mat();
		mHirerchy = new Mat();
		contours = new ArrayList<MatOfPoint>();
	}

	public void onCameraViewStopped() {
		mRgba.release();
		mGray.release();
		mGrayMat0.release();
		mHirerchy.release();
		contours.clear();
	}

	public Mat onCameraFrame(CvCameraViewFrame inputframe) {
		
		// sound counter init 
	    Red_cnt = 0;
	    Green_cnt = 0;
	    
		mRgba = inputframe.rgba();
		mGray = inputframe.gray();

		Imgproc.Canny(mRgba, mGrayMat0, 48, 120);
		
		Imgproc.findContours(mGrayMat0, contours, mHirerchy, Imgproc.RETR_LIST,
				Imgproc.CHAIN_APPROX_SIMPLE);
		Imgproc.drawContours(mRgba, contours, -1, new Scalar(Math.random()*255, Math.random()*255, Math.random()*255));//, 2, 8, hierarchy, 0, new Point());
	    
	    approxCurve = new MatOfPoint2f();
	    //For each contour found
        for (int i=0; i<contours.size(); i++)
        {
            //Convert contours(i) from MatOfPoint to MatOfPoint2f
            contour2f = new MatOfPoint2f( contours.get(i).toArray() );
            //Processing on mMOP2f1 which is in type MatOfPoint2f
            approxDistance = Imgproc.arcLength(contour2f, true)*0.02;
            Imgproc.approxPolyDP(contour2f, approxCurve, approxDistance, true);

            //Convert back to MatOfPoint
            MatOfPoint points = new MatOfPoint( approxCurve.toArray() );

            // Get bounding rect of contour
            Rect subrect = Imgproc.boundingRect(points);
            
            	// 세로가 가로보다 큰지
            if( subrect.height > subrect.width){
            	// rect의 가운데 좌표의 rgb 값을 확인.
            	Scalar rect_color = new Scalar(mRgba.get(subrect.x+(subrect.width/2), subrect.y+(subrect.height/1)));
            	Log.d(TAG, "rgba color: (" + rect_color.val[0] + ", " + rect_color.val[1] + ", " + rect_color.val[2] + ", " + rect_color.val[3] + ")");
            	
            	// color is red
            	if((rect_color.val[0] >= 200.0d)&&(rect_color.val[1] <= 210.0d)&&(rect_color.val[2] <= 210.0d)&&(rect_color.val[3]==255.0)) {
            		Log.d(TAG, " RED ");
            		Red_cnt++;
            	}else if ((rect_color.val[0] <= 210.0d)&&(rect_color.val[1] >= 200.0d)&&(rect_color.val[2] <= 210.0d)&&(rect_color.val[3]==255.0)){
            		Log.d(TAG, " Green ");
            		Green_cnt++;
            	}else
            		Log.d(TAG, " Not Red and Green ");
            }
            // draw enclosing rectangle (all same color, but you could use variable i to make them unique)
            // Point(subrect.x+subrect.width , subrect.y+subrect.height , new Scalar(255, 0, 0, 255), 3);
        }

        if(Red_cnt >= 1){
        	toneG_Red.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200);	
        }
        if(Green_cnt >= 1){
    		toneG_Green.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 100);
        }
        
		contours.clear();

		return mRgba;
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mOpenCvCameraView != null)
			mOpenCvCameraView.disableView();
	}

	public void onResume() {
		super.onResume();
		OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_10, this,
				mOpenCVCallBack);
	}

	public void onDestroy() {
		super.onDestroy();
		mOpenCvCameraView.disableView();
	}

}
