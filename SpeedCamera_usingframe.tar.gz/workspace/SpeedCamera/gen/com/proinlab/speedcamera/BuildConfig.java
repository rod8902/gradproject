/** Automatically generated file. DO NOT MODIFY */
package com.proinlab.speedcamera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}