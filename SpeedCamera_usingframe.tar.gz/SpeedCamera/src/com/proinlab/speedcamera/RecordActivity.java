package com.proinlab.speedcamera;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import java.util.*;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase.*;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;

public class RecordActivity extends Activity implements CvCameraViewListener2 {

	private Mat mRGBMat;
	private Mat mHSVMat;
	private Mat mGrayMat;
	private Mat mGrayMat0;
	private Mat mHirerchy;

	private Mat mRgba;
	private Mat mGray;

	private List<MatOfPoint> contours;

	private String TAG = "OPENCV ERROR";
	private CameraBridgeViewBase mOpenCvCameraView;

	private BaseLoaderCallback mOpenCVCallBack = new BaseLoaderCallback(this) {
		@Override
		public void onManagerConnected(int status) {
			switch (status) {
			case LoaderCallbackInterface.SUCCESS: {
				mOpenCvCameraView.enableView();

			}
				break;
			default: {
				super.onManagerConnected(status);
			}
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_record);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.record_activity_surface_view);
		mOpenCvCameraView.setCvCameraViewListener(this);

	}

	public void onCameraViewStarted(int width, int height) {
		mRgba = new Mat();
		mGray = new Mat();
		mRGBMat = new Mat();
		mHSVMat = new Mat();
		mGrayMat = new Mat();
		mGrayMat0 = new Mat();
		mHirerchy = new Mat();
		contours = new ArrayList<MatOfPoint>();

		Scalar RECT_COLOR = new Scalar(255, 0, 0);

	}

	public void onCameraViewStopped() {
		mRgba.release();
		mGray.release();
	}

	public Mat onCameraFrame(CvCameraViewFrame inputframe) {
		
		mRgba = inputframe.rgba();
		mGray = inputframe.gray();

//		Imgproc.cvtColor(inputFrame, mRGBMat, Imgproc.COLOR_RGBA2BGR);
//		Imgproc.cvtColor(mRGBMat, mHSVMat, Imgproc.COLOR_BGR2HSV);
//		Core.inRange(mHSVMat, new Scalar(9, 70, 80, 0), new Scalar(30, 255,
//				255, 0), mGrayMat);
//		// some smoothing of the image
//		for (int i = 0; i < 10; i++) {
//			Imgproc.GaussianBlur(mGrayMat, mGrayMat, new Size(9, 9), 2, 2);
//		}
//		Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_DILATE,
//				new Size(3, 3), new Point(1, 1));
		Imgproc.Canny(mRgba, mGrayMat0, 48, 120);
		
//		Imgproc.dilate(mGrayMat0, mGrayMat0, kernel);
//		kernel.release();
//		List<MatOfPoint> contours = new Vector<MatOfPoint>();
		Imgproc.findContours(mGrayMat0, contours, mHirerchy, Imgproc.RETR_LIST,
				Imgproc.CHAIN_APPROX_SIMPLE);
		mHirerchy.release();
		Imgproc.drawContours(mRgba, contours, -1, new Scalar(Math.random()*255, Math.random()*255, Math.random()*255));//, 2, 8, hierarchy, 0, new Point());

	    MatOfPoint2f approxCurve = new MatOfPoint2f();
	    
	    int rect_num = 0;
	    //For each contour found
        for (int i=0; i<contours.size(); i++)
        {
            //Convert contours(i) from MatOfPoint to MatOfPoint2f
            MatOfPoint2f contour2f = new MatOfPoint2f( contours.get(i).toArray() );
            //Processing on mMOP2f1 which is in type MatOfPoint2f
            double approxDistance = Imgproc.arcLength(contour2f, true)*0.02;
            Imgproc.approxPolyDP(contour2f, approxCurve, approxDistance, true);

            //Convert back to MatOfPoint
            MatOfPoint points = new MatOfPoint( approxCurve.toArray() );

            // Get bounding rect of contour
            Rect subrect = Imgproc.boundingRect(points);
            
            	// 세로가 가로보다 큰지
            if( subrect.height > subrect.width){
            	// rect의 가운데 좌표의 rgb 값을 확인.
            	
            	
            }
            
            

            // draw enclosing rectangle (all same color, but you could use variable i to make them unique)
            // Point(subrect.x+subrect.width , subrect.y+subrect.height , new Scalar(255, 0, 0, 255), 3); 
        }

//		Mat lines = new Mat(); // finds houghlines in the contours
//		Imgproc.HoughLinesP(mGrayMat0, lines, 1, Math.PI / 180, 1);
//		for (int x = 0; x < lines.cols(); x++) {
//			double[] vec = lines.get(0, x);
//			double x1 = vec[0], y1 = vec[1], x2 = vec[2], y2 = vec[3];
//			Point start = new Point(x1, y1);
//			Point end = new Point(x2, y2);
//			Core.line(mRgba, start, end, RECT_COLOR, 1);
//
//		}
		contours.clear();

		return mRgba;
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mOpenCvCameraView != null)
			mOpenCvCameraView.disableView();
	}

	public void onResume() {
		super.onResume();
		OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_10, this,
				mOpenCVCallBack);
	}

	public void onDestroy() {
		super.onDestroy();
		mOpenCvCameraView.disableView();
	}

}
